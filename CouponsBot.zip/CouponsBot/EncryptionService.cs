﻿using System.Security.Cryptography;

namespace TelegramBotCoupons
{
    public class EncryptionService
    {
        private static EncryptionService instance;
        public static EncryptionService Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new EncryptionService();
                }
                return instance;
            }
        }
        private EncryptionService() { }

        public byte[] GenerateIvFromString(string key)
        {
            byte[] keyBytes = System.Text.Encoding.UTF8.GetBytes(key);
            return getKeyBytes(keyBytes, 128);
        }
        private byte[] GenerateAesKeyFromString(string key)
        {
            byte[] keyBytes = System.Text.Encoding.UTF8.GetBytes(key);
            return getKeyBytes(keyBytes, 256);
        }

        private byte[] getKeyBytes(byte[] keyBytes, int baseNumber)
        {
            using (var deriveBytes = new Rfc2898DeriveBytes(keyBytes, keyBytes, 10000))
            {
                var aesKey = deriveBytes.GetBytes(baseNumber / 8); // AES key
                return aesKey;
            }
        }

        public byte[] Encrypt(string data, string key)
        {
            using (Aes aes = Aes.Create())
            {
                aes.Key = Instance.GenerateAesKeyFromString(key); // Use Instance to call the method
                aes.IV = Instance.GenerateIvFromString(key); // Ensure IV is generated correctly

                ICryptoTransform encryptor = aes.CreateEncryptor(aes.Key, aes.IV);

                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, encryptor, CryptoStreamMode.Write))
                    {
                        using (StreamWriter sw = new StreamWriter(cs))
                        {
                            sw.Write(data);
                        }
                    }
                    return ms.ToArray();
                }
            }
        }

        // Update the Decrypt method to call the instance method
        public string Decrypt(byte[] encryptedData, string key)
        {
            using (Aes aes = Aes.Create())
            {
                aes.Key = Instance.GenerateAesKeyFromString(key); // Use Instance to call the method
                aes.IV = Instance.GenerateIvFromString(key); // Ensure IV is generated correctly

                ICryptoTransform decryptor = aes.CreateDecryptor(aes.Key, aes.IV);

                using (MemoryStream ms = new MemoryStream(encryptedData))
                {
                    using (CryptoStream cs = new CryptoStream(ms, decryptor, CryptoStreamMode.Read))
                    {
                        using (StreamReader sr = new StreamReader(cs))
                        {
                            return sr.ReadToEnd();
                        }
                    }
                }
            }
        }

    }
}