﻿using Azure.Storage.Blobs;
using Newtonsoft.Json;

namespace TelegramBotCoupons
{
    public class UsersService
    {
        public class User
        {
            public long Id { get; set; }
            public string Username { get; set; }
            public Guid CouponsKeyId { get; set; }
            public CurrentDialog currentDialog { get; set; }
            public long collaborationPassword { get; set; }
            public DateTime lastActionTime { get; set; }
            public Guid collaborationKey { get; set; }

            public User(long userId, string? username)
            {
                Id = userId;
                Username = username ?? $"User {Id}";
                CouponsKeyId = Guid.NewGuid();
                collaborationKey = Guid.NewGuid();
                collaborationPassword = new Random().Next(100001, 1000000);
            }

            public void resetDialog()
            {
                currentDialog = CurrentDialog.None;
            }
        }

        // Enum: CurrentDialog
        public enum CurrentDialog
        {
            None,
            AddCoupon,
            Collaboration,
            Delete,
            Edit
        }

        public readonly BlobServiceClient blobServiceClient;
        private readonly BlobContainerClient containerClient;

        private static UsersService instance;
        public static UsersService Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new UsersService();
                }
                return instance;
            }
        }

        private UsersService()
        {
            containerClient = CouponsBot.GetInstanceAsync().Result.blobServiceClient.GetBlobContainerClient("users");
        }

        public async Task<User> GetUser(long userId, string? username = null)
        {
            var blobClient = containerClient.GetBlobClient($"{userId}.json");

            // Check if the user exists
            if (!blobClient.Exists())
            {
                var newUser = new User(userId, username);
                var userJson = JsonConvert.SerializeObject(newUser);
                var encryptedData = EncryptionService.Instance.Encrypt(data: userJson, key: userId.ToString());

                using (var stream = new MemoryStream(encryptedData))
                {
                    await blobClient.UploadAsync(stream, overwrite: true);
                }
                CollaborationService.Instance.createNewCollaborationForNewUser(newUser);
                return newUser;
            }
            else
            {
                var userData = await blobClient.DownloadContentAsync();
                var decryptedUserData = EncryptionService.Instance.Decrypt(userData.Value.Content.ToArray(), key: userId.ToString());
                var user = JsonConvert.DeserializeObject<User>(decryptedUserData);

                return user;
            }
        }

        //Get Users:
        public async Task<List<User>> GetUsers()
        {
            var users = new List<User>();
            await foreach (var blobItem in containerClient.GetBlobsAsync())
            {
                var blobClient = containerClient.GetBlobClient(blobItem.Name);
                var userData = await blobClient.DownloadContentAsync();
                var decryptedUserData = EncryptionService.Instance.Decrypt(userData.Value.Content.ToArray(), key: blobItem.Name.Split('.')[0]);
                var user = JsonConvert.DeserializeObject<User>(decryptedUserData);
                users.Add(user);
            }
            return users;
        }

        // UserId - user I want to collaborate with, collaboratorId - my id
        public async Task<bool> AddUsersCollaboration(long mainUserId, long collaboratorId, long password)
        {
            try
            {
                var userBlobClient = containerClient.GetBlobClient($"{mainUserId}.json");
                var collaboratorBlobClient = containerClient.GetBlobClient($"{collaboratorId}.json");

                // Get user data
                var userData = await userBlobClient.DownloadContentAsync();
                var decryptedUserData = EncryptionService.Instance.Decrypt(userData.Value.Content.ToArray(), key: mainUserId.ToString());
                var mainUser = JsonConvert.DeserializeObject<User>(decryptedUserData);

                if (password == mainUser?.collaborationPassword)
                {
                    // Get collaborator data
                    var collaboratorData = await collaboratorBlobClient.DownloadContentAsync();
                    var decryptedCollaboratorData = EncryptionService.Instance.Decrypt(collaboratorData.Value.Content.ToArray(), key: collaboratorId.ToString());
                    var collaborator = JsonConvert.DeserializeObject<User>(decryptedCollaboratorData);

                    // Add the collaborator coupons to the main user coupons
                    await CouponsService.Instance.CopyCoupons(mainUser, collaborator);

                    mainUser.collaborationPassword = new Random().Next(100001, 1000000);

                    // Update the main user data, including the new collaboration password
                    await Instance.UpdateUser(mainUser);
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch
            {
                throw new Exception("Failed to add collaboration. Please ensure the details and/or try again in a few minutes...");
            }            
        }

        // UpdateUser:
        public async Task<bool> UpdateUser(User user)
        {
            var blobClient = containerClient.GetBlobClient($"{user.Id}.json");
            // Check if the user exists
            if (!await blobClient.ExistsAsync())
            {
                return false;
            }
            // Serialize the user to JSON
            var userJson = JsonConvert.SerializeObject(user);
            var encryptedData = EncryptionService.Instance.Encrypt(data: userJson, key: user.Id.ToString());
            // Upload the encrypted data to the blob
            using (var stream = new MemoryStream(encryptedData))
            {
                await blobClient.UploadAsync(stream, overwrite: true);
            }

            return true;
        }
    }
}
