﻿using Telegram.Bot;
using Telegram.Bot.Types;
using User = TelegramBotCoupons.UsersService.User;

namespace TelegramBotCoupons
{
    internal class ContactDialog : IDialog
    {
        //Singleton:
        private static ContactDialog instance;
        public static ContactDialog Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new ContactDialog();
                }
                return instance;
            }
        }
        private ContactDialog() { }

        public CouponsService couponsService = CouponsService.Instance;

        public async Task Explain(long userId)
        {
            await CouponsBot.GetInstanceAsync().Result.botClient.SendMessage(
                chatId: userId,
                text: "Please send the message you want me to send to our support: give as many details as you can."
            );
        }

        public async Task Talk(Message message, User user)
        {
            var bot = await CouponsBot.GetInstanceAsync();
            try
            {
                await bot.botClient.SendMessage(
                   chatId: bot.managerUserId,
                   text: $"User {user.Id} sent a message to support:\n\n {message.Text}"
               );

                await bot.botClient.SendMessage(
                    chatId: user.Id,
                    text: "Your message has been sent to our support. We will get back to you as soon as possible."
                );
            }
            catch
            {
                await bot.botClient.SendMessage(
                    chatId: user.Id,
                    text: "An error occurred, please try again later."
                );
            }
        }
    }
}
