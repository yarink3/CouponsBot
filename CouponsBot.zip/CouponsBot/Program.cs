var builder = WebApplication.CreateBuilder(args);

// ? Register API controllers
builder.Services.AddControllers()
    .AddJsonOptions(options =>
    {
        options.JsonSerializerOptions.PropertyNameCaseInsensitive = true;
    });


var app = builder.Build();

// ? Map controllers
app.MapControllers();

// ? Start API (bot runs in the background)
app.Run();