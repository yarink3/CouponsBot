﻿using Telegram.Bot.Types;
using User = TelegramBotCoupons.UsersService.User;

namespace TelegramBotCoupons
{
    internal interface IDialog
    {
        Task Talk(Message message,User user = null);

        Task Explain(long userId);
    }
}
