﻿using Azure.Storage.Blobs;
using Newtonsoft.Json;
using User = TelegramBotCoupons.UsersService.User;

namespace TelegramBotCoupons
{
    class Collaboration
    {
        public List<long> usersIds { get; set; }
    }

    public class CollaborationService
    {
        private readonly BlobServiceClient blobServiceClient;
        private readonly BlobContainerClient containerClient;
        private readonly string containerName;

        // singleton:
        private static CollaborationService instance;
        public static CollaborationService Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new CollaborationService();
                }
                return instance;
            }
        }
        private CollaborationService()
        {
            blobServiceClient = CouponsBot.GetInstanceAsync().Result.blobServiceClient;
            containerName = "collaborations";
            containerClient = blobServiceClient.GetBlobContainerClient(containerName);
        }

        //Set new collaboration:
        public async Task<bool> SetCollaboration(User mainUser, User collaborator)
        {
            //download main user collaboration
            var mainUserBlobClient = containerClient.GetBlobClient(mainUser.collaborationKey.ToString());
            var mainUserBlobDownloadInfo = await mainUserBlobClient.DownloadContentAsync();
            var mainUserDecryptedData = EncryptionService.Instance.Decrypt(mainUserBlobDownloadInfo.Value.Content.ToArray(), key: mainUser.collaborationKey.ToString());
            var mainUserCollaboration = JsonConvert.DeserializeObject<Collaboration>(mainUserDecryptedData);

            //download collaborator collaboration
            var blobClient = containerClient.GetBlobClient(collaborator.collaborationKey.ToString());
            var blobDownloadInfo = await blobClient.DownloadContentAsync();
            var decryptedData = EncryptionService.Instance.Decrypt(blobDownloadInfo.Value.Content.ToArray(), key: collaborator.collaborationKey.ToString());
            var collaboratorCollaboration = JsonConvert.DeserializeObject<Collaboration>(decryptedData);

            foreach (var userId in collaboratorCollaboration.usersIds)
            {
                var user = await UsersService.Instance.GetUser(userId);
                user.collaborationKey = mainUser.collaborationKey;
                user.CouponsKeyId = mainUser.CouponsKeyId;
                
                //TODO: make sure im in myself list
                
                mainUserCollaboration.usersIds.Add(userId);

                await UsersService.Instance.UpdateUser(user);

            }

            var json = JsonConvert.SerializeObject(mainUserCollaboration);
            var encryptedData = EncryptionService.Instance.Encrypt(data: json, key: mainUser.collaborationKey.ToString());
            using (var stream = new MemoryStream(encryptedData))
            {
                await mainUserBlobClient.UploadAsync(stream, overwrite: true);
            }

            return true;
        }

        public void createNewCollaborationForNewUser(User user)
        {
            // Create a new collaboration object for the user
            var newCollaboration = new Collaboration
            {
                usersIds = new List<long> { user.Id }
            };

            // Serialize the collaboration object to JSON
            var json = JsonConvert.SerializeObject(newCollaboration);

            // Encrypt the JSON data
            var encryptedData = EncryptionService.Instance.Encrypt(data: json, key: user.collaborationKey.ToString());

            // Upload the encrypted data to the blob container
            var blobClient = containerClient.GetBlobClient(user.collaborationKey.ToString());
            using (var stream = new MemoryStream(encryptedData))
            {
                blobClient.UploadAsync(stream, overwrite: true).Wait();
            }
        }
    }
}
