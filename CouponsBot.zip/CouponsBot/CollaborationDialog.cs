﻿using Telegram.Bot.Types;
using User = TelegramBotCoupons.UsersService.User;
using Telegram.Bot;

namespace TelegramBotCoupons
{

    class CollaborationDialog : IDialog
    {

        // singleton:
        private static CollaborationDialog instance;
        public static CollaborationDialog Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new CollaborationDialog();
                }
                return instance;
            }
        }

        private CollaborationDialog() { }

        public async Task Explain(long userId)
        {
            await CouponsBot.GetInstanceAsync().Result.botClient.SendMessage(
                chatId: userId,
                text: "Please ask your friend to send me the following message.\nPay attention, all your collaborated coupons will be shared with your friend."
                );

            await CouponsBot.GetInstanceAsync().Result.botClient.SendMessage(
            chatId: userId,
                text: $"Collaborate with {userId} {UsersService.Instance.GetUser(userId).Result.collaborationPassword}"
            );
        }

        public async Task Talk (Message message, User user)
        {

            try
            {
                var command = message.Text.Substring(4).Trim(); // Remove "add" and trim spaces
                var parts = command.Split(' ');

                if (parts.Length != 4)
                {
                    await CouponsBot.GetInstanceAsync().Result.botClient.SendMessage(
                        chatId: message.Chat.Id,
                        text: "Invalid format. Please use: Collaborate with <user id> <temporary passcode>"
                    );
                    return;
                }

                // Extract Company, Value, and optional Link
                var mainUserId = long.Parse(parts[2].Trim());
                var password = long.Parse(parts[3].Trim());

                if (await UsersService.Instance.AddUsersCollaboration(mainUserId, message.Chat.Id, password))
                {
                    await CouponsBot.GetInstanceAsync().Result.botClient.SendMessage(
                        chatId: message.Chat.Id,
                        text: "Collaboration started :), Now your and your partner can see the same coupons."
                    );
                }
                else
                {
                    await CouponsBot.GetInstanceAsync().Result.botClient.SendMessage(
                        chatId: message.Chat.Id,
                        text: "Collaboration failed :( , try again or /contact us"
                    );
                }
            }
            catch (Exception e)
            {
                await CouponsBot.GetInstanceAsync().Result.botClient.SendMessage(
                    chatId: message.Chat.Id,
                    text: "Collaboration failed :( , try again or /contact us"
                );
            }
        }

    }
}
