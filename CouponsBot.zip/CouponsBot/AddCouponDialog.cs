﻿
using Telegram.Bot.Types;
using User = TelegramBotCoupons.UsersService.User;
using Telegram.Bot;

namespace TelegramBotCoupons
{
    internal class AddCouponDialog : IDialog
    {
        public CouponsService couponsService = CouponsService.Instance;

        // singleton:
        private static AddCouponDialog instance;
        public static AddCouponDialog Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new AddCouponDialog();
                }
                return instance;
            }
        }

        private AddCouponDialog() { }

        public async Task Explain(long userId)
        {
            await CouponsBot.GetInstanceAsync().Result.botClient.SendMessage(
                chatId:userId,
                text: "To add a coupon, please use the following format: [Company],[Value],[Link],[expiration-date] (comma separated, link and exp. date are optional).\n" +
                      "For example: McDonalds,10,mcdonalds.com/123,31/12/2021 \n\n" +
                      "To add a Cibus coupon, just paste the message you got from cibus."
            );
        }

        public async Task Talk(Message message, User user)
        {
            if(message.Text.StartsWith("לצפיה"))
            {
                await HandleCibusMessage(message, user);
                return;
            }

            try
            {
                // "company, value, link, expiration date" or "company, value"
                var parts = message.Text.Split(',');

                if (parts.Length < 2 || parts.Length > 4)
                {
                    await CouponsBot.GetInstanceAsync().Result.botClient.SendMessage(
                        chatId: message.Chat.Id,
                        text: "Invalid format. Please use: [Company],[Value],[Link],[expiration-date] (comma separated, link and exp. date are optional)"
                    );
                    return;
                }

                // Extract Company, Value, and optional Link
                var company = parts[0].Trim();               // Company
                var value = decimal.Parse(parts[1].Trim());                 // Value
                var link = parts.Length > 2 ? parts[2].Trim() : null; // Link (optional)
                DateTime? expirationDate = null;
                if (parts.Length > 3)
                {
                    if (DateTime.TryParseExact(parts[3].Trim(), new[] { "dd/MM/yyyy" }, null, System.Globalization.DateTimeStyles.None, out DateTime parsedDate))
                    {
                        expirationDate = parsedDate;
                    }
                    else
                    {
                        await CouponsBot.GetInstanceAsync().Result.botClient.SendMessage(
                            chatId: message.Chat.Id,
                            text: "Invalid date format. Please use: dd/MM/yyyy"
                        );
                        return;
                    }
                }

                var coupon = new Coupon
                {
                    Company = company,
                    Value = value,
                    Link = link,
                    ExpirationDate = expirationDate
                };


                await couponsService.AddCoupon(message, coupon);
                await CouponsBot.GetInstanceAsync().Result.botClient.SendMessage(
                    chatId: message.Chat.Id,
                    text: "Coupon added successfully."
                );
            }
            catch
            {
                await CouponsBot.GetInstanceAsync().Result.botClient.SendMessage(
                    chatId: message.Chat.Id,
                    text: "Failed to add coupon... Try again"
                );
            }
        }

        public async Task HandleCibusMessage(Message message, User user = null)
        {
            try
            {
                var coupon = couponsService.ParseCibusCoupon(message);
                var addCouponmessage = await couponsService.AddCoupon(message, coupon);
                await CouponsBot.GetInstanceAsync().Result.botClient.SendMessage(
                    chatId: message.Chat.Id,
                    text: addCouponmessage
                );
            }
            catch
            {
                await CouponsBot.GetInstanceAsync().Result.botClient.SendMessage(
                    chatId: message.Chat.Id,
                    text: "Failed to add coupon... Try again"
                );
            }
        }
    }
}
