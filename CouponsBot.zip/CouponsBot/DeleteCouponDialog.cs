﻿using Telegram.Bot;
using Telegram.Bot.Types;
using User = TelegramBotCoupons.UsersService.User;

namespace TelegramBotCoupons
{
    internal class DeleteCouponDialog : IDialog
    {
        //Singleton:
        private static DeleteCouponDialog instance;
        public static DeleteCouponDialog Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new DeleteCouponDialog();
                }
                return instance;
            }
        }
        private DeleteCouponDialog() { }

        public CouponsService couponsService = CouponsService.Instance;

        public async Task Explain(long userId)
        {
            var couponsListString = await couponsService.GetCouponsAsString(userId);
            await CouponsBot.GetInstanceAsync().Result.botClient.SendMessage(
                chatId: userId,
                text: $"{couponsListString}\n\n" +
                "Please enter the IDs of the coupons you want to delete, separated by commas.(for example 2,5,6)"
            );
        }

        public async Task Talk(Message message, User user)
        {
            try
            {
                var idList = couponsService.ProcessDeleteCommand(message.Text);
                var deletedCouponsString = await couponsService.DeleteCoupons(userId: message.Chat.Id, idList);

                await CouponsBot.GetInstanceAsync().Result.botClient.SendMessage(
                    chatId: message.Chat.Id,
                    text: deletedCouponsString
                );
            }
            catch
            {
                await CouponsBot.GetInstanceAsync().Result.botClient.SendMessage(
                    chatId: message.Chat.Id,
                    text: "An error occurred, please try again later."
                );
            }
        }

    }
}
