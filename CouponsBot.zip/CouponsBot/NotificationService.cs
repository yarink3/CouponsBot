﻿using Telegram.Bot;

namespace TelegramBotCoupons
{
    internal class NotificationService
    {
        // Singleton:
        private static NotificationService instance;
        
        private UsersService usersService = UsersService.Instance;
        private CouponsService couponsService = CouponsService.Instance;

        public static NotificationService Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new NotificationService();
                }
                return instance;
            }
        }
        private NotificationService() { }

        // Check for expiring coupons and notify the user:
        public async Task CheckForExpiringCoupons()
        {
            var users = await usersService.GetUsers();
            foreach (var user in users)
            {
                var expiringCoupons = await couponsService.GetCoupons(user.Id, onlyExpiring: true);
                if (expiringCoupons.Count > 0)
                {
                    var message = "Your coupons are expiring:\n\n";
                    message += string.Join("\n", expiringCoupons.Select(c => c.ToString()));
                    await NotifyUser(user.Id, message);
                }
            }
        }

        public async Task NotifyUser(long userId, string message)
        {
            await CouponsBot.GetInstanceAsync().Result.botClient.SendMessage(
                chatId: userId,
                text: message
            );
        }
    }
}
