﻿using Telegram.Bot;
using Telegram.Bot.Types;
using User = TelegramBotCoupons.UsersService.User;

namespace TelegramBotCoupons
{
    internal class EditValueDialog : IDialog
    {
        //Singleton:
        private static EditValueDialog instance;
        public static EditValueDialog Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new EditValueDialog();
                }
                return instance;
            }
        }
        private EditValueDialog() { }

        public CouponsService couponsService = CouponsService.Instance;

        public async Task Explain(long userId)
        {
            var couponsListString = await couponsService.GetCouponsAsString(userId);
            await CouponsBot.GetInstanceAsync().Result.botClient.SendMessage(
                chatId: userId,
                text: $"{couponsListString}\n\n" +
                "Please enter the ID of the coupons you want to edit and its new value, for example: 3,280."
            );
        }

        public async Task Talk(Message message, User user)
        {
            try
            {
                //split the message text by comma
                var messageParts = message.Text.Split(',');
                //check if the message has two parts
                if (messageParts.Length != 2)
                {
                    await CouponsBot.GetInstanceAsync().Result.botClient.SendMessage(
                        chatId: message.Chat.Id,
                        text: "Please enter the ID of the coupon and its new value, separated by a comma. For example: 3,280."
                    );
                    return;
                }

                //parse the id and value from the message
                if (!int.TryParse(messageParts[0].Trim(), out int couponId))
                {
                    await CouponsBot.GetInstanceAsync().Result.botClient.SendMessage(
                        chatId: message.Chat.Id,
                        text: "Invalid coupon ID. Please enter a valid number."
                    );
                    return;
                }
                if (!decimal.TryParse(messageParts[1].Trim(), out decimal newValue))
                {
                    await CouponsBot.GetInstanceAsync().Result.botClient.SendMessage(
                        chatId: message.Chat.Id,
                        text: "Invalid coupon value. Please enter a valid number."
                    );
                    return;
                }
                //call the EditCouponValue method with the parsed id and value
                var editedCouponsString = await couponsService.EditCouponValue(userId: message.Chat.Id, couponId: couponId, newValue: newValue);
               
                await CouponsBot.GetInstanceAsync().Result.botClient.SendMessage(
                    chatId: message.Chat.Id,
                    text: editedCouponsString
                );
            }
            catch
            {
                await CouponsBot.GetInstanceAsync().Result.botClient.SendMessage(
                    chatId: message.Chat.Id,
                    text: "An error occurred, please try again later."
                );
            }
        }

    }
}
