﻿using Azure.Storage.Blobs;
using Azure.Storage.Blobs.Models;
using Newtonsoft.Json;
using System.Text.RegularExpressions;
using Telegram.Bot.Types;
using User = TelegramBotCoupons.UsersService.User;

namespace TelegramBotCoupons
{
    public class Coupon
    {
        public string? Id { get; set; }
        public string Link { get; set; }
        public decimal Value { get; set; }
        public string Company { get; set; }
        public DateTime? ExpirationDate { get; set; }
        public long AdderUserId { get; set; }

        
        public override string ToString()
        {
            var basicText = $"Company: {Company}, Value: {Value}";
            var linkText = Link != null && Link != "" ? $", Link: {Link}" : "";
            var expirationText = ExpirationDate.HasValue ? $", Expiration Date: {ExpirationDate.Value.ToShortDateString()}" : "";
            return basicText + linkText + expirationText;
        }
    }

    public class CouponsService
    {
        private readonly BlobContainerClient containerClient;

        // Constructor with singleton:
        private static CouponsService instance;
        public static CouponsService Instance
        {
            get
            {
                if (instance == null)
                {
                    instance = new CouponsService();
                }
                return instance;
            }
        }

        private CouponsService()
        {
            containerClient = CouponsBot.GetInstanceAsync().Result.blobServiceClient.GetBlobContainerClient("coupons");
        }

        // Method to validate date is exist:
        public bool ValidateDate(string date)
        {
            var t = DateTime.TryParse(date, out _);
            return t;
        }


        public async Task<string> AddCoupon(Message message, Coupon coupon)
        {
            try
            {
                var dateIsValid = coupon.ExpirationDate.HasValue ? ValidateDate(coupon.ExpirationDate.Value.ToShortDateString()) : true;
                if (!dateIsValid)
                {
                    throw new Exception("Invalid date format. Please use: DD/MM/YYYY");
                }

                var user = UsersService.Instance.GetUser(message.Chat.Id).Result;

                var username = message?.From?.Username;
                coupon.AdderUserId = user.Id;

            
                coupon.Id = Guid.NewGuid().ToString();
                var blobClient = containerClient.GetBlobClient($"{user.CouponsKeyId}/{coupon.Id}.json");

                var serializedData = JsonConvert.SerializeObject(coupon);
                var encryptedCoupon = EncryptionService.Instance.Encrypt(data: serializedData, key: user.collaborationKey.ToString());
                await blobClient.UploadAsync(new BinaryData(encryptedCoupon), overwrite: true);
                return "Coupon added successfully!";
            }
            catch
            {
                throw new Exception("Failed to add coupon. Please check the details or try again in a few minutes... ");
            }
        }

        public async Task<List<Coupon>> GetCoupons(long userId, bool onlyExpiring = false, string getOnlyCompany = null)

        { 
        string decryptedData;
            try
            {
                var user = UsersService.Instance.GetUser(userId).Result;
                var CouponsKeyId = user.CouponsKeyId;
                var UserCouponsBlobClient = containerClient.GetBlobClient(CouponsKeyId.ToString());
                var coupons = new List<Coupon>();
                var couponsBlobs = containerClient.GetBlobsAsync(prefix: $"{CouponsKeyId}/");


                await foreach (var blob in couponsBlobs)
                {
                    var blobClient = containerClient.GetBlobClient(blob.Name);
                    var blobDownloadInfo = await blobClient.DownloadContentAsync();
                     decryptedData = EncryptionService.Instance.Decrypt(blobDownloadInfo.Value.Content.ToArray(), key: user.collaborationKey.ToString());
                    var coupon = JsonConvert.DeserializeObject<Coupon>(decryptedData);
                    if (coupon == null)
                    {
                        throw new Exception("Failed to get coupons. Please try again in a few minutes...");
                    }
                    
                    if(getOnlyCompany != null)
                    {
                        if(Equals(getOnlyCompany, coupon.Company))
                        {
                            coupons.Add(coupon);
                        }
                        continue;
                    }

                    if (!onlyExpiring  || ( coupon.ExpirationDate.HasValue && coupon.ExpirationDate.Value.Date <= DateTime.Today.AddDays(14)))
                    {
                        coupons.Add(coupon);
                    }
                }

                //order by company name and then by value and then by expiration date:
                coupons = coupons.OrderBy(c => c.Company).ThenBy(c => c.Value).ThenBy(c => c.ExpirationDate.HasValue ? c.ExpirationDate : DateTime.MaxValue).ToList();

                return coupons;
            }
            catch
            {
                throw new Exception("Failed to get coupons. Please try again in a few minutes...");
            }
        }
        public async Task<string> EditCouponValue(long userId, int couponId, decimal newValue)
        {
            try
            {
                var coupons = GetCoupons(userId).Result;
                var coupon = coupons[couponId - 1];
                if (coupon == null)
                {
                    throw new Exception("Coupon not found.");
                }
                coupon.Value = newValue;

                var user = await UsersService.Instance.GetUser(userId);
                var blobClient = containerClient.GetBlobClient($"{user.CouponsKeyId}/{coupon.Id}.json");
                var serializedData = JsonConvert.SerializeObject(coupon);
                var encryptedCoupon = EncryptionService.Instance.Encrypt(data: serializedData, key: user.collaborationKey.ToString());
                await blobClient.UploadAsync(new BinaryData(encryptedCoupon), overwrite: true);
                return $"Coupon value updated successfully.\n\n" +
                    $"Company: {coupon.Company}\n" +
                    $"Value: {coupon.Value} ";
            }
            catch
            {
                throw new Exception("Failed to update coupon value. Please try again in a few minutes...");
            }
        }


        // returns failed ids to delete
        public async Task<string> DeleteCoupons(long userId, List<int> idsToDelete)
        {
            try
            {
                var coupons = GetCoupons(userId).Result;
                var CouponsKeyId = UsersService.Instance.GetUser(userId).Result.CouponsKeyId;
                var failedIds = new List<int>();
                var deletedCouponsString = "";
                
                // Delete the requested coupons:
                foreach (var id in idsToDelete)
                {
                    var coupon = coupons[id-1];
                    if (coupon == null)
                    {
                        failedIds.Add(id);
                        continue;
                    }
                    var blobClient = containerClient.GetBlobClient($"{CouponsKeyId}/{coupon.Id}.json");
                    await blobClient.DeleteAsync();
                    deletedCouponsString += $"{id}. {coupon.ToString()}\n\n";
                }
                if(deletedCouponsString != "")
                {
                    deletedCouponsString = "Deleted coupons:\n\n" + deletedCouponsString;
                }

                if (failedIds.Count > 0)
                {
                    deletedCouponsString += $"*Failed to delete coupons with Ids:* {string.Join(", ", failedIds)}\n\n";
                }

                return deletedCouponsString;
            }
            catch
            {
                throw new Exception("Failed to delete coupons. Please try again in a few minutes...");
            }
        }

        public Coupon ParseCibusCoupon(Message message)
        {
            var text = message.Text;

            var companyNameMatch = Regex.Match(text, @"לצפיה בשובר (.+?) בסך"); // Extract company name
            var valueMatch = Regex.Match(text, @"בסך ₪([\d.]+)"); // Extract value
            var linkMatch = Regex.Match(text, @"https?://\S+"); // Extract URL

            if (!companyNameMatch.Success || !valueMatch.Success || !linkMatch.Success)
            {
                throw new Exception("Unable to parse cibus coupon");
            }

            return new Coupon
            {
                Company = companyNameMatch.Groups[1].Value,
                Value = decimal.Parse(valueMatch.Groups[1].Value),
                Link = linkMatch.Value,
                AdderUserId = message.Chat.Id
            };
        }

        public async Task<string> GetCouponsAsString(long chatId, bool includeCompanySums = false, string getOnlyCompany = null)
        {
            var couponsList = await GetCoupons(chatId, getOnlyCompany: getOnlyCompany);
            if (couponsList.Count == 0)
            {
                return "You have no coupons.";
            }
            var response = 
                $"Your Coupons List:\n\n" + 
                string.Join("\n\n", couponsList.Select((c, i) =>
                $"{i + 1}" + ". " + c.ToString()
            ));

            if (includeCompanySums)
            {
                var companySums = couponsList
                    .GroupBy(c => c.Company)
                    .Select(g => new
                    {
                        Company = g.Key,
                        Sum = g.Sum(c => c.Value)
                    });
                response += "\n\nTotal:\n";
                response += string.Join("\n", companySums.Select((c, i) =>
                    $"{i + 1}" + ". " + c.Company + ": " + c.Sum
                ));
            }
            return response;
        }

        public async Task<string> ParseCouponseList(long chatId)
        {
            var couponsList = await GetCoupons(chatId);
            if (couponsList.Count == 0)
            {
                return "You have no coupons.";
            }
            var response = string.Join("\n", couponsList.Select((c, i) =>
                $"{i + 1}" + ". " + c.ToString()
            ));

            return response;
        }

        public List<int> ProcessDeleteCommand(string text)
        {
            var match = Regex.Match(text, @"([\d,]+)", RegexOptions.IgnoreCase);
            var idList = match.Groups[1].Value
              .Split(',')
              .Select(id => int.TryParse(id.Trim(), out var parsedId) ? parsedId : -1)
              .Where(id => id > 0)
              .ToList();

            return idList;
        }

        public async Task CopyCoupons(User user, User collaborator)
        {
            try
            {
                // Get colalborator's coupons:
                var collaboratorCoupons = GetCoupons(collaborator.Id).Result;
                var userCoupons = GetCoupons(user.Id).Result;

                var sourceFolderName = $"{collaborator.CouponsKeyId}";
                var targetFolderName = $"{user.CouponsKeyId}";

                BlobClient sourceBlobFolder = containerClient.GetBlobClient(sourceFolderName);
                //BlobClient targetBlob = containerClient.GetBlobClient(targetBlobName);

                // List all blobs in the source folder
                await foreach (BlobItem blobItem in containerClient.GetBlobsAsync(prefix: sourceFolderName + "/"))
                {
                    string sourceBlobName = blobItem.Name;
                    string destinationBlobName = sourceBlobName.Replace(sourceFolderName, targetFolderName); // Keep the same structure

                    BlobClient sourceBlob = containerClient.GetBlobClient(sourceBlobName);
                    BlobClient destinationBlob = containerClient.GetBlobClient(destinationBlobName);

                    // Decrypt blob content:
                    var blobDownloadInfo = await sourceBlob.DownloadContentAsync();
                    var decryptedData = EncryptionService.Instance.Decrypt(blobDownloadInfo.Value.Content.ToArray(), key: collaborator.collaborationKey.ToString());

                    //encrypt blob content with new key and upload to destination:
                    var encryptedData = EncryptionService.Instance.Encrypt(data: decryptedData, key: user.collaborationKey.ToString());
                    await destinationBlob.UploadAsync(new BinaryData(encryptedData), overwrite: true);

                    // Delete the source blob
                    await sourceBlob.DeleteIfExistsAsync();

                }

                await CollaborationService.Instance.SetCollaboration(user, collaborator);

            }
            catch
            {
                throw new Exception("Failed to set collaboration. Please try again in a few minutes...");
            }
        }
    }
}