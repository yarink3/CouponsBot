
using Microsoft.AspNetCore.Mvc;
using TelegramBotCoupons;

[ApiController]
[Route("notifications")] 
public class NotificationsController : ControllerBase
{
    [HttpGet("notify/{password}")]
    public IActionResult Notify(string password)
    {
        if (password == CouponsBot.GetInstanceAsync().Result.serverPassword)
        {
            try
            {
                NotificationService.Instance.CheckForExpiringCoupons();
                return Ok("Notified Users");
            }
            catch (Exception e)
            {
                return StatusCode(500, e.Message);
            }
        }
        return Unauthorized();
    }
}
