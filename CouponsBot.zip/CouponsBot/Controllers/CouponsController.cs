﻿using Microsoft.AspNetCore.Mvc;
using Telegram.Bot.Types;
using Telegram.Bot;
using TelegramBotCoupons;
using Azure.Storage.Blobs;

[ApiController]
public class CouponsController : ControllerBase
{
    public static CouponsService couponsService;
    public static EncryptionService aesEncryptionService;
    public static BlobServiceClient blobServiceClient;


    [HttpGet("start/{password}")]
    public async Task<string> Start(string password)
    {
        if (password == (await CouponsBot.GetInstanceAsync()).serverPassword)
        {
            await (await CouponsBot.GetInstanceAsync()).Main();
        }
        return "CouponsBot Started :)";
    }

    [HttpPost("debug/{password}")]
    public async Task<IActionResult> Webhook([FromBody] Update update, string password)
    {
        if (password != (await CouponsBot.GetInstanceAsync()).serverPassword)
        {
            return Unauthorized();
        }
        await (await CouponsBot.GetInstanceAsync()).HandleUpdateAsync(null, update, HttpContext.RequestAborted);
        return Ok();
    }
}
