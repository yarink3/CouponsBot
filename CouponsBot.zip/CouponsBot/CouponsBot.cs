﻿using Azure.Storage.Blobs;
using Telegram.Bot.Types;
using Telegram.Bot;
using Azure.Identity;
using Azure.Security.KeyVault.Secrets;
using static TelegramBotCoupons.UsersService;

namespace TelegramBotCoupons
{
    internal class CouponsBot
    {
        public CouponsService couponsService;
        public EncryptionService aesEncryptionService;
        public BlobServiceClient blobServiceClient;
        public TelegramBotClient botClient;
        public static string storageAccountName = "<Storage Account Name>";
        public static string keyVaultName = "<Key Vault Name>";
        public long managerUserId = 0; // Set the manager's user id here
        public string serverPassword = ""; // Set the server password here

        //Singleton:
        private static CouponsBot instance;

        

        public static async Task<CouponsBot> GetInstanceAsync()
        {
            if (instance == null)
            {
                instance = await CreateBot();
            }
            return instance;
        }

        private CouponsBot() {}

        public static async Task<CouponsBot> CreateBot()
        {
            var bot = new CouponsBot();

            var kv_url = $"https://{keyVaultName}.vault.azure.net/";
            var secretClient = new SecretClient(new Uri(kv_url), new DefaultAzureCredential());
            var secret = secretClient.GetSecretAsync("<App Secret Key>").GetAwaiter().GetResult().Value.Value;
            var botToken = secretClient.GetSecretAsync("<Token Key>").GetAwaiter().GetResult().Value.Value;
            var AppClientId = secretClient.GetSecretAsync("<Client Id Key>").GetAwaiter().GetResult().Value.Value;
            var AppTenantId = secretClient.GetSecretAsync("<Tenant Id Key>").GetAwaiter().GetResult().Value.Value;

            var clientCredential = new ClientSecretCredential(AppTenantId, AppClientId, secret);

            bot.blobServiceClient = new BlobServiceClient(
                new Uri($"https://{storageAccountName}.blob.core.windows.net"),
                clientCredential
            );

            bot.botClient = new TelegramBotClient(botToken);

            return bot;
        }
        public async Task log(string message)
        {
            try
            {
                await botClient.SendMessage(
                                    chatId: managerUserId,
                                    text: message
                                );
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error sending log message: {message} , try change the managerUserId value");
            }
        }

        public async Task HandleUpdateAsync(ITelegramBotClient botClient, Update update, CancellationToken cancellationToken)
        {
            if(botClient == null)
            {
                botClient = this.botClient;
            }
            var message = update.Message;
            IDialog? dialog = null;
            var userId = message.Chat.Id;
            var user = UsersService.Instance.GetUser(userId).Result;
            if ((DateTime.Now - user.lastActionTime).TotalMinutes > 10)
            {
                user.resetDialog();
            }

            user.lastActionTime = DateTime.Now;

            switch (user.currentDialog)
            {
                case UsersService.CurrentDialog.None:
                    {
                        switch (message.Text.Trim().ToLower())
                        {
                            case "/start" or "start":
                                message.Chat.FirstName = message.Chat.FirstName ?? "User";
                                await botClient.SendMessage(
                                    chatId: userId,
                                    text: "Welcome! Use /add to add a coupon, /list, list <company>, to see all coupons," +
                                    " or /delete. You can also use /collaborate to share all coupons between friends"
                                );
                                return;

                            case "/help" or "help":
                                message.Chat.FirstName = message.Chat.FirstName ?? "User";
                                await botClient.SendMessage(
                                    chatId: userId,
                                    text: "I would be happy to help you :) You can use these commands:\n\n" +
                                    "/add: Add a coupon (or just paste cibuse message).\n\n" +
                                    "/list or list,<company>: See all coupons / see all <company> coupons.\n\n" +
                                    "/delete : Delete coupon(s) according to your choise(s).\n\n" +
                                    "/collaborate: Share all coupons between friends.\n\n"+
                                    "/contact: Contact the bot manager.\n\n"
                                );
                                return;

                            case "/add" or "add" or "הוסף" or "הוספה":
                                user.currentDialog = UsersService.CurrentDialog.AddCoupon;
                                dialog = AddCouponDialog.Instance;
                                break;

                            case "/list" or "list" or "רשימה":
                                var couponsListString = await couponsService.GetCouponsAsString(userId, includeCompanySums: true);
                                await botClient.SendMessage(
                                    chatId: userId,
                                    text: couponsListString
                                );
                                return;

                            case "/delete" or "delete" or "מחק" or "מחיקה":
                                user.currentDialog = UsersService.CurrentDialog.Delete;
                                dialog = DeleteCouponDialog.Instance;
                                break;
                            case "/edit" or "edit" or "ערוך" or "עריכה":
                                user.currentDialog = UsersService.CurrentDialog.Edit;
                                dialog = EditValueDialog.Instance;
                                break;

                            case "/collaborate" or "collaborate" or "collaboration" or "שיתוף":
                                await CollaborationDialog.Instance.Explain(userId);
                                break;

                            case "/contact" or "contact":
                                dialog = ContactDialog.Instance;
                                break;

                            default:
                                if (message.Text.StartsWith("לצפיה"))
                                {
                                    await AddCouponDialog.Instance.HandleCibusMessage(message);
                                }
                                else if (message.Text.StartsWith("Collaborate"))
                                {
                                    await CollaborationDialog.Instance.Talk(message, user);
                                    return;
                                }
                               
                                else if (new[] { "list", "רשימה" }.Any(message.Text.Trim().ToLower().StartsWith) )
                                {
                                    var parts = message.Text.Trim().Split(',');
                                    if (parts.Length != 2)
                                    {
                                        await botClient.SendMessage(
                                             chatId: userId,
                                             text: "I'm sorry, I didn't understand that. Please use /help for instructions."
                                         );
                                        return;
                                    }
                                    var companyName = parts[1].Trim();
                                    couponsListString = await couponsService.GetCouponsAsString(userId, includeCompanySums: true, getOnlyCompany: companyName);
                                    await botClient.SendMessage(
                                        chatId: userId,
                                        text: couponsListString
                                    );
                                    return;
                                }
                                else
                                {
                                    await botClient.SendMessage(
                                        chatId: userId,
                                        text: "I'm sorry, I didn't understand that. Please use /help for instructions."
                                    );
                                }

                                break;
                        }
                    }

                    dialog?.Explain(userId);
                    await UsersService.Instance.UpdateUser(user);
                    return;

                case UsersService.CurrentDialog.AddCoupon:
                    dialog = AddCouponDialog.Instance;
                    break;
                case UsersService.CurrentDialog.Delete:
                    dialog = DeleteCouponDialog.Instance;
                    break;
                case CurrentDialog.Edit:
                    dialog = EditValueDialog.Instance;
                    break;
                default:
                    break;
            }

            dialog?.Talk(message, user);
            user.resetDialog();
            await UsersService.Instance.UpdateUser(user);
        }

        public Task HandleErrorAsync(ITelegramBotClient botClient, Exception exception, CancellationToken cancellationToken)
        {
            Console.WriteLine($"Error: {exception.Message}");
            return Task.CompletedTask;
        }

        public async Task Main()
        {
            couponsService = CouponsService.Instance;
            aesEncryptionService = EncryptionService.Instance;

            botClient.StartReceiving(
                HandleUpdateAsync,
                HandleErrorAsync
            );

            Console.WriteLine("Bot is up and running!");
            Console.ReadLine();
        }
    }
}
